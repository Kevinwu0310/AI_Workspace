# Project Context & Guidelines

## Session Recovery
- **Crucial:** At the start of every new session, read the end of `JOURNAL.md` to recover the current state, active goals, and the immediate next step.
- **Context Sync:** Always read `CLAUDE_TRANSFER.md` and `CONVERSATION_HISTORY.txt` in full to recover user profiles, coding styles, technical integrations (like FreeLLMAPI), and full project history.
- **Manual Recovery:** When the user types `/load` or `./load`, perform a "Recovery" sequence:
    1. Read `CLAUDE.md`, `JOURNAL.md`, `CLAUDE_TRANSFER.md`, and `CONVERSATION_HISTORY.txt`.
    2. Summarize the recovered state, active goals, and the immediate "Next Step".
    3. Confirm that the state is loaded and ready.
- **Closing Protocol:** When the user types `/save`, perform a "Checkpoint" sequence:
    1. Summarize current progress and pending tasks.
    2. Append a detailed "Checkpoint" entry to `JOURNAL.md` including the current date, status, and explicit "Next Step".
    3. Update any long-term facts in the memory system.
    4. Confirm the session state is preserved.
- Before ending a session or completing a major task, append a "Checkpoint" entry to `JOURNAL.md`.

## Development Workflow
- Match surrounding code style, naming, and comment density.
- Use the memory system for long-term facts, but use `JOURNAL.md` for session-to-session continuity.
