import easyocr
import cv2
import os
import re
import time
import pyautogui
import numpy as np

# ==========================================
# PRECISE COORDINATES (Generous Bottom Edge)
# ==========================================
STRINGS_X1, STRINGS_Y1 = 247, 342
STRINGS_X2, STRINGS_Y2 = 573, 680 # Pushed down from 650
VALUES_X1, VALUES_Y1 = 567, 346
VALUES_X2, VALUES_Y2 = 653, 680 # Pushed down from 650

# ==========================================
# DATA LIBRARY (The Source of Truth)
# ==========================================
STAT_LIBRARY = {
    "Crit. Rate": {"type": "percent", "vals": [6.3, 6.9, 7.5, 8.1, 8.7, 9.3, 9.9, 10.5]},
    "Crit. DMG": {"type": "percent", "vals": [12.6, 13.8, 15.0, 16.2, 17.4, 18.6, 19.8, 21.0]},
    "Energy Regen": {"type": "percent", "vals": [6.8, 7.6, 8.4, 9.2, 10.0, 10.8, 11.6, 12.4]},
    "ATK%": {"type": "percent", "vals": [6.4, 7.1, 7.9, 8.6, 9.4, 10.1, 10.9, 11.6]},
    "HP%": {"type": "percent", "vals": [6.4, 7.1, 7.9, 8.6, 9.4, 10.1, 10.9, 11.6]},
    "DEF%": {"type": "percent", "vals": [6.4, 7.1, 7.9, 8.6, 9.4, 10.1, 10.9, 11.6]},
    "Flat ATK": {"type": "flat", "vals": [30, 40, 50, 60]},
    "Flat DEF": {"type": "flat", "vals": [40, 50, 60, 70]},
    "Flat HP": {"type": "flat", "vals": [320, 360, 390, 430, 470, 510, 540, 580]},
    "DMG Bonus": {"type": "percent", "vals": [6.4, 7.1, 7.9, 8.6, 9.4, 10.1, 10.9, 11.6]},
}

def map_label(raw_label):
    text = raw_label.lower()
    if not text: return None
    if ("crit" in text) and ("dmg" in text or "omg" in text or "m" in text): return "Crit. DMG"
    if ("crit" in text) and ("rate" in text or "r" in text or "ate" in text): return "Crit. Rate"
    if "regen" in text or "er" in text or "energy" in text: return "Energy Regen"
    if any(x in text for x in ["heavy", "attack", "bonus", "skill", "basic"]): return "DMG Bonus"
    if "hp" in text: return "HP"
    if "def" in text or "dee" in text: return "DEF"
    if "atk" in text: return "ATK"
    return f"Unknown ({raw_label})"

def resolve_identity_and_value(raw_label, raw_value):
    text = raw_label.lower()
    clean_val_str = re.sub(r'[^0-9.]', '', raw_value)
    if not clean_val_str: return None, None

    try:
        val = float(clean_val_str)
    except ValueError: return None, None

    if "atk" in text:
        if val >= 20: return "Flat ATK", val
        return "ATK%", val
    if "def" in text or "dee" in text:
        if val >= 20: return "Flat DEF", val
        return "DEF%", val
    if "hp" in text:
        if val >= 100: return "Flat HP", val
        return "HP%", val
    if ("crit" in text) and ("dmg" in text or "omg" in text or "m" in text):
        return "Crit. DMG", (val / 10.0 if val > 20 else val)
    if ("crit" in text) and ("rate" in text or "r" in text or "ate" in text):
        return "Crit. Rate", (val / 10.0 if val > 20 else val)
    if "regen" in text or "er" in text or "energy" in text:
        return "Energy Regen", (val / 10.0 if val > 20 else val)
    if any(x in text for x in ["heavy", "attack", "bonus", "skill", "basic"]):
        return "DMG Bonus", (val / 10.0 if val > 20 else val)

    return f"Unknown ({raw_label})", val

def find_closest_valid_value(stat_name, value):
    if stat_name not in STAT_LIBRARY:
        return value
    valid_vals = STAT_LIBRARY[stat_name]["vals"]
    closest_val = min(valid_vals, key=lambda x: abs(x - value))
    diff = abs(closest_val - value)
    if STAT_LIBRARY[stat_name]["type"] == "flat":
        if diff > 5: return None
    else:
        if diff > 0.5: return None
    return closest_val

def run_neural_scanner():
    print("🧠 Neural Echo Scanner [FINAL BOUNDARY] starting...")
    try:
        reader = easyocr.Reader(['en'], gpu=False)
    except Exception as e:
        print(f"Error: {e}")
        return

    print("\n✅ LIVE MONITOR ACTIVE. Press Ctrl+C to stop.\n")

    try:
        while True:
            full_screenshot = pyautogui.screenshot()
            frame = cv2.cvtColor(np.array(full_screenshot), cv2.COLOR_RGB2BGR)
            strings_zone = frame[STRINGS_Y1:STRINGS_Y2, STRINGS_X1:STRINGS_X2]
            values_zone = frame[VALUES_Y1:VALUES_Y2, VALUES_X1:VALUES_X2]

            # SAVE THE FINAL CROP for user verification
            cv2.imwrite("final_eye_strings.png", strings_zone)
            cv2.imwrite("final_eye_values.png", values_zone)

            raw_labels = reader.readtext(strings_zone)
            raw_values = reader.readtext(values_zone)

            raw_labels.sort(key=lambda x: x[0][0][1])
            raw_values.sort(key=lambda x: x[0][0][1])

            final_stats = {}
            num_pairs = min(len(raw_labels), len(raw_values))
            for i in range(num_pairs):
                label_text = raw_labels[i][1]
                value_text = raw_values[i][1]
                clean_label, parsed_val = resolve_identity_and_value(label_text, value_text)
                if clean_label:
                    final_val = find_closest_valid_value(clean_label, parsed_val)
                    if final_val is not None:
                        final_stats[clean_label] = final_val

            print("\n--- 🌟 FINALIZED STATS ---")
            if not final_stats:
                print("Scanning... (No stats found)")
            else:
                for label, value in final_stats.items():
                    unit = "%" if (label in STAT_LIBRARY and STAT_LIBRARY[label]["type"] == "percent") else ""
                    print(f"{label}: {value}{unit}")
            print("---------------------------")
            time.sleep(2)

    except KeyboardInterrupt:
        print("\nStopped by user. Goodbye!")

if __name__ == "__main__":
    run_neural_scanner()
